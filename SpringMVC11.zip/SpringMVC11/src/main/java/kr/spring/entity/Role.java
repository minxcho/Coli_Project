package kr.spring.entity;

public enum Role {
	FREE, STANDARD, PRO;
}
